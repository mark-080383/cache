// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

package azkeys

const (
	moduleName = "github.com/Azure/azure-sdk-for-go/sdk/security/keyvault/azkeys"
	version    = "v1.4.0"
)
